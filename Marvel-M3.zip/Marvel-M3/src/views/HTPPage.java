package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class HTPPage implements ActionListener {

	JFrame frame;
	JLabel label ;
	ImageIcon image;
	JLabel rule;
	JButton back;
	HomePage home;
	public HTPPage() {
		
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setTitle("Marvel Game");
		ImageIcon marvel = new ImageIcon("marvelgame.png");
		frame.setIconImage(marvel.getImage());
		image = new ImageIcon( new ImageIcon("marvelhowtoplay.jpg").getImage().getScaledInstance(1650, 900, Image.SCALE_SMOOTH));
		label = new JLabel();
		label.setLayout(null);
		label.setIcon(image);
		frame.add(label,BorderLayout.CENTER);
		frame.setVisible(true);
		label.setLayout(null);
		
		rule = new JLabel();
		rule.setBounds(75,200,900,400);
		rule.setText("<html><body>&nbsp; Move &nbsp; : &nbsp; move the currently champion at a certain direction <br> "
				+ "&nbsp; Attack &nbsp; : &nbsp; attack the opponent champion at certain direction <br>"
				+ "&nbsp; Leader Ability &nbsp; : &nbsp; Used one time only in the game <br>"
				+ "&nbsp; Endturn &nbsp; : &nbsp; to end the turn <br> "
				+ "&nbsp; Ability: &nbsp; : &nbsp; to cast an ability on the opponent champion <br>"
				+ "&nbsp; &nbsp; &nbsp; SingleTarget &nbsp; : &nbsp; cast an ability on a specific target using (x,y) notation <br>"
				+ "&nbsp; &nbsp; &nbsp; Directional &nbsp; : &nbsp; cast an ability on targets for certain direction <br>"
				+ "&nbsp; &nbsp; &nbsp; Surround &nbsp; : &nbsp; cast an ability on surrounded targets within the range <br>"
				+ "&nbsp; &nbsp; &nbsp; TeamTarget &nbsp; : &nbsp; cast an ability on targets within the range");
		
		rule.setFont(new Font("Times",Font.PLAIN,25));
		rule.setVerticalAlignment(JLabel.CENTER);
		rule.setHorizontalAlignment(JLabel.CENTER);
		rule.setBorder(BorderFactory.createDashedBorder(Color.gray, 5, 10));
		rule.setForeground(Color.white);
		label.add(rule);
		
		back = new JButton("Return");
		back.setBounds(0,745,200,50);
		back.setBackground(new Color(255,205,0));
		back.setFont(new Font(null,Font.BOLD,30));
		back.setFocusable(false);
		back.setForeground(Color.black);
		back.addActionListener(this);
		
		label.add(back);
		frame.revalidate();
		frame.repaint();
	}
	@Override
	public void actionPerformed(ActionEvent e) {

			if(e.getSource()==back) {
				frame.dispose();
				home = new HomePage();
			}
	}
	
}
