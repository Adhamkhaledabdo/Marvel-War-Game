package views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import engine.Game;

public class Controller {

	Game game;
	StartPage start;
	ChampionPage prepare;
	PlayPage play;
	Credits credit;
	
	public Controller() throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		 
		start = new StartPage();	
		
	}
		
	
	public static void main (String [] args) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		
		Controller AllViews = new Controller();
		

}
}
