package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class StartPage implements KeyListener {
	
	JFrame frame;
	ImageIcon image;
	JLabel label;
	JLabel label2;
	HomePage home;
	
	public StartPage () throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		
		File file = new File("avenger.wav");
		AudioInputStream audiostream = AudioSystem.getAudioInputStream(file);
		Clip clip = AudioSystem.getClip();

		clip.open(audiostream);
		clip.start();
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setBackground(Color.white);
		frame.setTitle("Marvel Game");
		ImageIcon marvel = new ImageIcon("marvelgame.png");
		frame.setIconImage(marvel.getImage());
		frame.setVisible(true);
		image = new ImageIcon (new ImageIcon("marvell.jpg").getImage().getScaledInstance(1560,800,Image.SCALE_SMOOTH));
		label = new JLabel();
		label.setLayout(null);
		label.setIcon(image);
		frame.add(label,BorderLayout.CENTER);
		frame.setVisible(true);
		
		label2 = new JLabel("<html><body>&nbsp;Press space to start");
		label2.setForeground(Color.white);
		label2.setFont(new Font("Monospaced",Font.ITALIC,28));
		label2.setHorizontalTextPosition(JLabel.CENTER);
		label2.setVerticalTextPosition(JLabel.CENTER);
		label2.setBounds(580, 650, 375, 60);
		//label2.setBorder(BorderFactory.createDashedBorder(new Color(0,0,70),5 ,2));
		//label2.setBorder(BorderFactory.createDashedBorder(null, 2, 5, 5, true));
		label.add(label2);
		frame.addKeyListener(this);
		
		frame.revalidate();
		frame.repaint();
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.getKeyChar()==' ')
		{
			frame.dispose();
			home = new HomePage ();
		}
			
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
