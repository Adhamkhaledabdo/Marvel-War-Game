package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.security.DomainCombiner;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;

public class HomePage implements ActionListener{

	JFrame frame;
	JLabel label;
	ImageIcon image;
	JButton quit;
	JButton game;
	JButton credits;
	JButton howtoplay;
	Credits credit;
	ChampionPage load;
	HTPPage howplay;
	
	
	public HomePage() {
		
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBackground(Color.black);
		frame.setLayout(new BorderLayout());
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setTitle("Marvel Game");
		ImageIcon marvel = new ImageIcon("marvelgame.png");
		frame.setIconImage(marvel.getImage());
		image = new ImageIcon( new ImageIcon("captainma.jpg").getImage().getScaledInstance(1560, 900, Image.SCALE_SMOOTH));
		label = new JLabel();
		label.setLayout(null);
		label.setIcon(image);
		frame.add(label,BorderLayout.CENTER);
		frame.setVisible(true);
		Border b = BorderFactory.createLineBorder(null, 2,true);
		game = new JButton ("New Game");
		game.setFocusable(false);
		game.setFont(new Font ("Serif", Font.BOLD, 20));
		game.setBounds(200,500,200,70);
		game.setBackground(new Color(0,0,50));
		game.setForeground(Color.white);
		game.setBorder(b);
		label.add(game);
		quit = new JButton ("Quit Game");
		quit.setFocusable(false);
		quit.setFont(new Font ("Serif", Font.BOLD, 20));
		quit.setBounds(1155,500,200,70);
		quit.setBackground(new Color(0,0,50));
		quit.setForeground(Color.white);
		quit.setBorder(b);
		label.add(quit);
		credits = new JButton ("Credits");
		credits.setFocusable(false);
		credits.setFont(new Font ("Serif", Font.BOLD, 20));
		credits.setBounds(955,670,200,70);
		credits.setBackground(new Color(0,0,50));
		credits.setForeground(Color.white);
		credits.setBorder(b);
		label.add(credits);
		howtoplay = new JButton ("How To Play");
		howtoplay.setFocusable(false);
		howtoplay.setFont(new Font ("Serif", Font.BOLD, 20));
		howtoplay.setBounds(400,670,200,70);
		howtoplay.setBackground(new Color(0,0,50));
		howtoplay.setForeground(Color.white);
		howtoplay.setBorder(b);
		label.add(howtoplay);
		quit.addActionListener(this);
		game.addActionListener(this);
		howtoplay.addActionListener(this);
		credits.addActionListener(this);

		frame.revalidate();
		frame.repaint();
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==quit)
		{
			frame.dispose();
		}
		
		if(e.getSource()==credits)
		{
			frame.dispose();
			credit = new Credits();
		}
		if(e.getSource()==game)
		{
			frame.dispose();
			try {
				load = new ChampionPage();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getSource()==howtoplay) {
			frame.dispose();
			howplay = new HTPPage();
			
		}
		
		
		
	}
	
	
	
}
